<template>
  <div class="user-subscription-edit">
    <Header :cur="-1" @userInfoLoaded="handleUserInfoLoaded"></Header>
    <div class="container">
      <UserSidebar v-model="sidebarKey" />
      <div class="main">
        <div class="panel">
          <div class="panel-top">
            <div class="panel-title">{{ t("user.subscription.title") }}</div>
          </div>

          <div class="tip">{{ t("user.subscription.tip") }}</div>

          <div class="account-section">
            <div class="account-info">
              <img src="@/assets/images/user/account.png" alt="" />
              <div>
                <div class="section-title">
                  {{ t("user.subscription.accountTitle") }}
                </div>
                <div class="account-content">
                  <div v-if="hasAccount" class="account-status">
                    <img src="@/assets/images/user/success.png" alt="" />
                    {{ t("user.subscription.accountCreated") }}
                  </div>
                  <span v-else>{{ t("user.subscription.accountContent") }}</span>
                </div>
              </div>
            </div>
            <button class="create-account-btn" v-if="!hasAccount" @click="handleCreateAccount">{{ t("user.subscription.createAccount") }}</button>
            <span class="change-account-btn" v-else @click="handleChangeAccount">{{ t("user.subscription.changeAccount") }}</span>
          </div>

          <div class="sections-wrap">
            <div class="section">
              <div class="label">
                {{ t("user.subscription.priceLabel") }}
                <span class="info">{{ t("user.subscription.priceLimit") }}</span>
              </div>
              <div class="price-options">
                <div class="price-option" @click="selectedId = 0">
                  <div class="radio-circle">
                    <img src="@/assets/images/header/check_active.png" alt="" v-if="selectedId == 0" />
                    <img src="@/assets/images/header/check.png" alt="" v-else />
                  </div>
                  <span class="price-text">{{ t("user.subscription.cancel") }}</span>
                </div>
                <div
                  class="price-option"
                  v-for="option in priceOptions"
                  :key="option.id"
                  @click="selectedId = option.id"
                >
                  <div class="radio-circle">
                    <img src="@/assets/images/header/check_active.png" alt="" v-if="selectedId == option.id" />
                    <img src="@/assets/images/header/check.png" alt="" v-else />
                  </div>
                  <span class="price-text">{{ option.price }} {{ t('aiRecharge.unit') }}</span>
                </div>
              </div>
            </div>
            <div class="section">
              <div class="label">
                {{ t("user.subscription.benefitsLabel") }}
                <span class="count">{{ benefits.length }}/500</span>
              </div>
              <textarea
                class="textarea"
                v-model="benefits"
                :maxlength="500"
                spellcheck="false"
                :placeholder="t('user.subscription.benefitsText')"
              ></textarea>
            </div>
            <div class="actions">
              <button class="btn btn-cancel" @click="onCancel">
                {{ t("user.interactive.cancel") }}
              </button>
              <button class="btn btn-save" :disabled="saving" @click="onSave">
                {{ t("user.profile.save") }}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <UploadMask :visible="isLoading" :text="t('loading')" />
</template>

<script setup lang="ts" name="UserSubscriptionEdit">
import Header from "@/components/Header.vue";
import UserSidebar from "@/components/UserSidebar.vue";
import UploadMask from "@/components/UploadMask.vue";
import { ref, onMounted } from "vue";
import { useI18n } from "vue-i18n";
import router from "@/router";
import api from "@/api/index";
import { toast } from "@/util/toast";
const { t, locale } = useI18n();

const sidebarKey = ref("subscription");
const priceOptions = [
  { id: 45, price: "1000" },
  { id: 46, price: "2000" },
  { id: 47, price: "3000" }
];
const selectedId = ref(0);
const benefits = ref("");
const saving = ref(false);
const loading = ref(false);
const plan = ref<any>(null);
const isLoading = ref(false);
const hasAccount = ref(false);

onMounted(async () => {
  await fetchSubscription();
});

function handleUserInfoLoaded(userData: any) {
  hasAccount.value = userData?.info?.blogger_status === '1';
}

async function fetchSubscription() {
  loading.value = true;
  try {
    const res = await api.getSubscription();
    const data = res as unknown as { code: number; msg: string; msg_jp: string; data?: any };

    if (data.code === 200 || data.code === 0) {
      plan.value = data.data?.plan;
      const description = data.data?.plan?.description;
      const planId = data.data?.plan?.plan_id;

      if (plan.value) {
        const option = priceOptions.find(opt => opt.id == planId);
        selectedId.value = option?.id || 1;
      } else {
        selectedId.value = 0;
      }

      benefits.value = description || "";
    } else {
      toast(locale.value == 'jp' ?  data.msg_jp : data.msg)
    }
  } catch (error) {
    console.error(error);
    toast(t("fail"));
  } finally {
    loading.value = false;
  }
}

function onCancel() {
  router.push("/user-subscription");
}

async function handleCreateAccount() {
  try {
    isLoading.value = true;
    const res = await api.createAccount();
    const data = res as any;

    if (data.code === 200 || data.code === 0) {
      window.open(data.data?.url, '_blank');
    } else {
      toast(locale.value == 'jp' ? data.msg_jp : data.msg);
    }
  } catch (error) {
    toast(t("fail"));
  } finally {
    isLoading.value = false;
  }
}

async function handleChangeAccount() {
  try {
    isLoading.value = true;
    const res = await api.benefit();
    const data = res as any;

    if (data.code === 200 || data.code === 0) {
      window.open(data.data?.url, '_blank');
    } else {
      toast(locale.value == 'jp' ? data.msg_jp : data.msg);
    }
  } catch (error) {
    toast(t("fail"));
  } finally {
    isLoading.value = false;
  }
}

async function onSave() {
  if (!hasAccount.value) {
    await handleCreateAccount();

    return false;
  }

  saving.value = true;
  try {
    const params = {
      plan_id: selectedId.value,
      description: benefits.value
    };

    const res = await api.modifySubscription(params);
    const data = res as unknown as { code: number; msg: string; msg_jp: string; data?: any };

    if (data.code === 200 || data.code === 0) {
      toast(t('success'));

      router.push("/user-subscription");
    } else {
      toast(locale.value == 'jp' ?  data.msg_jp : data.msg)
    }
  } catch (error) {
    console.error(error);
    toast(t("fail"));
  } finally {
    saving.value = false;
  }
}
</script>

<style scoped lang="scss">
.user-subscription-edit {
  width: 100%;
  min-height: 100vh;
  background: #FFFFFF;
}
.container {
  max-width: 144rem;
  margin: 0 auto;
  display: flex;
  gap: 4.8rem;
  padding-right: 4.8rem;
}
.main {
  flex: 1;
  padding-top: 14rem;
}
.panel-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin: 0 0 2.4rem 1.2rem;
}
.panel-title {
  font-weight: 500;
  font-size: 2rem;
  color: #99A1AF;
}
.tip {
  display: flex;
  align-items: center;
  height: 5.4rem;
  margin: 0 1.2rem 1.2rem;
  padding: 1rem 1.6rem;
  border: 1px solid rgba(251,100,182,0.2);;
  border-radius: 0.8rem;
  font-size: 1.4rem;
  background: rgba(251,100,182,0.06);
  color: #364153;
}

.account-section {
  margin: 0 1.2rem 2.4rem;
  padding: 1.6rem;
  border-radius: 1.2rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #F5F5F5;
}

.account-info {
  flex: 1;
  display: flex;
  align-items: center;
  gap: 1.2rem;

  img{
    width: 5.2rem;
    height: 5.2rem;
  }
}

.section-title {
  margin-bottom: 0.8rem;
  font-weight: 500;
  font-size: 1.6rem;
  color: #101828;
  gap: 0.8rem;
}

.account-content {
  font-size: 1.4rem;
  color: #99A1AF;
  flex: 1;
}

.create-account-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  min-width: 13.6rem;
  height: 4.8rem;
  background: #fb64b6;
  color: #ffffff;
  border: none;
  border-radius: 0.8rem;
  font-size: 1.4rem;
  cursor: pointer;
  transition: all 0.2s ease;

  &:hover {
    position: relative;
    &::after {
      content: "";
      position: absolute;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background: rgba(255, 255, 255, 0.1);
      z-index: 1;
    }
  }
}

.change-account-btn {
  color: #99A1AF;
  font-size: 1.4rem;
  cursor: pointer;
}

.account-status {
  display: flex;
  align-items: center;
  font-size: 1.4rem;
  color: #6A7282;
  gap: 0.4rem;

  img{
    width: 2rem;
    height: 2rem;
  }
}
.sections-wrap {
  padding: 1.2rem;
  border-radius: 1.2rem;
  background: #F5F5F5;;
}
.section {
  margin-bottom: 2.4rem;
}
.label {
  font-size: 1.4rem;
  color: #6A7282;
  display: flex;
  align-items: center;
  gap: 0.8rem;
  .count {
    font-size: 1.2rem;
    color: #99a1af;
    font-weight: normal;
  }

  .info{
    font-size: 1.2rem;
    color: #99a1af;
    font-weight: normal;
  }
}
.price-options {
  display: flex;
  align-items: center;
  margin-top: 1.6rem;
  gap: 3.2rem;
}
.price-option {
  display: flex;
  align-items: center;
  gap: 0.8rem;
  cursor: pointer;
  .radio-circle {
    width: 2.4rem;
    height: 2.4rem;
    img{
      width: 100%;
      height: 100%;
    }
  }
  .price-text {
    font-size: 1.6rem;
    color: #364153;
  }
}
.textarea {
  width: 100%;
  height: 14rem;
  margin-top: 1.6rem;
  padding: 1.8rem 1.6rem;
  font-family: inherit;
  border: 1px solid #FFFFFF;
  border-radius: 0.8rem;
  background: #FFFFFF;
  outline: none;
  color: #364153;
}
.textarea:focus {
  border: 1px solid #fb64b6;
}
.textarea::placeholder {
  color: #99A1AF;
}
.actions {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 1rem;
}
.btn {
  height: 4.8rem;
  min-width: 13.6rem;
  padding: 0 1.6rem;
  border-radius: 0.8rem;
  cursor: pointer;
  font-size: 1.4rem;
  position: relative;
}
.btn-cancel {
  background: #FFFFFF;
  color: #6A7282;
}
.btn-cancel:hover {
  color: #fb64b6;
}
.btn-save {
  background: #fb64b6;
  border: none;
  color: #fff;
}
.btn-save:hover::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: 0.8rem;
  background: rgba(255, 255, 255, 0.1);
}
.btn:disabled {
  opacity: 0.6;
  cursor: default;
}
</style>
